screen_max_x=1024
screen_max_y=760
dirn=True
